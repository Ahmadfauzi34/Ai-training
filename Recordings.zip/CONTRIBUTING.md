# Contributing to Robust Test Runner

## Development Setup

```bash
# Clone repository
git clone <repo-url>
cd robust-test-runner

# Install dependencies
npm install

# Verify setup
npm run typecheck
npm test
```

## Code Style

- **Strict TypeScript**: All code must pass `tsc --noEmit` with zero errors
- **Zero allocation hot path**: No closure allocation in performance-critical code
- **SOA over AOS**: Use Structure of Arrays for bulk data processing
- **Branchless math**: Use `Math.abs`, ternary operators, or bit manipulation instead of `if/else` in tight loops
- **Explicit imports**: Use `node:` prefix for built-in modules

## Testing Guidelines

1. Every new feature must include unit tests
2. Use `StrictAssertions` for floating point comparisons
3. Include benchmark tests for performance-critical code
4. Integration tests required for CLI changes
5. Strict mode must pass (`STRICT_MODE=true npm test`)

## Pull Request Process

1. Fork and create feature branch
2. Run full test suite: `npm run test:ci`
3. Ensure type checking passes: `npm run typecheck`
4. Update documentation if needed
5. Submit PR with clear description

## Performance Budget

- Test runner overhead: < 5ms per 1000 tests
- Benchmark precision: ±1% variance acceptable
- Memory leak threshold: < 1MB per test suite
