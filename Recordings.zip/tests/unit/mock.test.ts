/**
 * Mock Utilities Tests
 * 
 * Validates zero-allocation mock system with SOA call logging.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  createMock,
  createAsyncMock,
  spyOn,
  stub,
  stubThrows,
  MockClock,
} from '../../src/utils/mock.js';

// ============================================================================
// SYNC MOCK TESTS
// ============================================================================

describe('createMock', { concurrency: 4 }, () => {
  it('creates callable mock function', () => {
    const mock = createMock<[number, number], number>();
    const result = mock(2, 3);

    assert.strictEqual(result, undefined);
    assert.strictEqual(mock.callCount(), 1);
    assert.strictEqual(mock.wasCalled(), true);
  });

  it('records call arguments', () => {
    const mock = createMock<[string, number], void>();
    mock('hello', 42);

    const lastCall = mock.lastCall();
    assert.ok(lastCall);
    assert.deepStrictEqual(lastCall!.args, ['hello', 42]);
  });

  it('returns fixed value', () => {
    const mock = createMock<[number], number>();
    mock.returnValue(100);

    assert.strictEqual(mock(1), 100);
    assert.strictEqual(mock(2), 100);
    assert.strictEqual(mock(3), 100);
  });

  it('uses custom implementation', () => {
    const mock = createMock<[number, number], number>();
    mock.implementation((a, b) => a + b);

    assert.strictEqual(mock(2, 3), 5);
    assert.strictEqual(mock(10, 20), 30);
  });

  it('throws configured error', () => {
    const mock = createMock<[], void>();
    mock.throws(new Error('test error'));

    assert.throws(() => mock(), /test error/);
    assert.strictEqual(mock.callCount(), 1);
  });

  it('checks if called with specific args', () => {
    const mock = createMock<[number, string], void>();
    mock(1, 'a');
    mock(2, 'b');

    assert.strictEqual(mock.wasCalledWith(1, 'a'), true);
    assert.strictEqual(mock.wasCalledWith(2, 'b'), true);
    assert.strictEqual(mock.wasCalledWith(3, 'c'), false);
  });

  it('resets state', () => {
    const mock = createMock<[], number>();
    mock.returnValue(42);

    mock();
    assert.strictEqual(mock.callCount(), 1);

    mock.reset();
    assert.strictEqual(mock.callCount(), 0);
    assert.strictEqual(mock(), undefined);
  });

  it('gets call by index', () => {
    const mock = createMock<[number], void>();
    mock(1);
    mock(2);
    mock(3);

    const call0 = mock.getCall(0);
    const call1 = mock.getCall(1);
    const call2 = mock.getCall(2);

    assert.deepStrictEqual(call0!.args, [1]);
    assert.deepStrictEqual(call1!.args, [2]);
    assert.deepStrictEqual(call2!.args, [3]);
    assert.strictEqual(mock.getCall(99), null);
  });

  it('records timestamps', () => {
    const mock = createMock<[], void>();
    const before = performance.now();
    mock();
    const after = performance.now();

    const lastCall = mock.lastCall();
    assert.ok(lastCall!.timestamp >= before);
    assert.ok(lastCall!.timestamp <= after);
  });

  it('handles default implementation', () => {
    const mock = createMock<[number], number>((x) => x * 2);

    assert.strictEqual(mock(5), 10);
    assert.strictEqual(mock(3), 6);
  });
});

// ============================================================================
// ASYNC MOCK TESTS
// ============================================================================

describe('createAsyncMock', { concurrency: 4 }, () => {
  it('creates callable async mock', async () => {
    const mock = createAsyncMock<[], number>();
    const result = await mock();

    assert.strictEqual(result, undefined);
    assert.strictEqual(mock.callCount(), 1);
  });

  it('resolves with fixed value', async () => {
    const mock = createAsyncMock<[], string>();
    mock.resolve('success');

    const result = await mock();
    assert.strictEqual(result, 'success');
  });

  it('rejects with error', async () => {
    const mock = createAsyncMock<[], void>();
    mock.reject(new Error('async error'));

    await assert.rejects(mock(), /async error/);
    assert.strictEqual(mock.callCount(), 1);
  });

  it('uses async implementation', async () => {
    const mock = createAsyncMock<[number], number>();
    mock.implementation(async (x) => x * x);

    const result = await mock(5);
    assert.strictEqual(result, 25);
  });

  it('records async call args', async () => {
    const mock = createAsyncMock<[string], string>();
    mock.resolve('result');

    await mock('input');
    const lastCall = mock.lastCall();

    assert.deepStrictEqual(lastCall!.args, ['input']);
  });

  it('resets async mock', async () => {
    const mock = createAsyncMock<[], number>();
    mock.resolve(42);

    await mock();
    mock.reset();

    assert.strictEqual(mock.callCount(), 0);
    const result = await mock();
    assert.strictEqual(result, undefined);
  });
});

// ============================================================================
// SPY TESTS
// ============================================================================

describe('spyOn', { concurrency: 4 }, () => {
  it('spies on object method', () => {
    const obj = {
      add(a: number, b: number): number {
        return a + b;
      },
    };

    const spy = spyOn(obj, 'add');

    const result = obj.add(2, 3);
    assert.strictEqual(result, 5); // Original behavior preserved
    assert.strictEqual(spy.callCount(), 1);
    assert.deepStrictEqual(spy.lastCall()!.args, [2, 3]);

    spy.restore();
  });

  it('restores original method', () => {
    const obj = {
      value: 42,
      getValue(): number {
        return this.value;
      },
    };

    const original = obj.getValue;
    const spy = spyOn(obj, 'getValue');

    spy.restore();
    assert.strictEqual(obj.getValue, original);
  });

  it('spies on multiple calls', () => {
    const obj = {
      counter: 0,
      increment(): number {
        return ++this.counter;
      },
    };

    const spy = spyOn(obj, 'increment');

    obj.increment();
    obj.increment();
    obj.increment();

    assert.strictEqual(spy.callCount(), 3);
    assert.strictEqual(obj.counter, 3);

    spy.restore();
  });
});

// ============================================================================
// STUB TESTS
// ============================================================================

describe('stub utilities', { concurrency: 4 }, () => {
  it('creates value stub', () => {
    const valueStub = stub(42);
    assert.strictEqual(valueStub(), 42);
    assert.strictEqual(valueStub(), 42);
  });

  it('creates error stub', () => {
    const errorStub = stubThrows(new Error('stubbed error'));
    assert.throws(errorStub, /stubbed error/);
  });

  it('stubs complex objects', () => {
    const obj = { a: 1, b: [2, 3] };
    const objStub = stub(obj);

    assert.deepStrictEqual(objStub(), obj);
  });
});

// ============================================================================
// MOCK CLOCK TESTS
// ============================================================================

describe('MockClock', { concurrency: 4 }, () => {
  it('starts at time 0', () => {
    const clock = new MockClock();
    assert.strictEqual(clock.now(), 0);
  });

  it('advances time', () => {
    const clock = new MockClock();
    clock.advance(1000);
    assert.strictEqual(clock.now(), 1000);

    clock.advance(500);
    assert.strictEqual(clock.now(), 1500);
  });

  it('executes timeout callbacks', () => {
    const clock = new MockClock();
    let called = false;

    clock.setTimeout(() => { called = true; }, 1000);
    assert.strictEqual(called, false);

    clock.advance(1000);
    assert.strictEqual(called, true);
  });

  it('executes multiple timeouts in order', () => {
    const clock = new MockClock();
    const order: number[] = [];

    clock.setTimeout(() => order.push(3), 300);
    clock.setTimeout(() => order.push(1), 100);
    clock.setTimeout(() => order.push(2), 200);

    clock.advance(300);
    assert.deepStrictEqual(order, [1, 2, 3]);
  });

  it('does not execute early timeouts', () => {
    const clock = new MockClock();
    let called = false;

    clock.setTimeout(() => { called = true; }, 1000);
    clock.advance(999);
    assert.strictEqual(called, false);

    clock.advance(1);
    assert.strictEqual(called, true);
  });

  it('clears timeout', () => {
    const clock = new MockClock();
    let called = false;

    const id = clock.setTimeout(() => { called = true; }, 1000);
    clock.clearTimeout(id);
    clock.advance(1000);

    assert.strictEqual(called, false);
  });

  it('handles multiple advances', () => {
    const clock = new MockClock();
    const calls: number[] = [];

    clock.setTimeout(() => calls.push(clock.now()), 100);
    clock.setTimeout(() => calls.push(clock.now()), 200);

    clock.advance(50);
    assert.deepStrictEqual(calls, []);

    clock.advance(100);
    assert.deepStrictEqual(calls, [150]);

    clock.advance(100);
    assert.deepStrictEqual(calls, [150, 250]);
  });

  it('resets state', () => {
    const clock = new MockClock();
    clock.advance(1000);
    clock.setTimeout(() => {}, 500);

    clock.reset();

    assert.strictEqual(clock.now(), 0);
    // Timer should not execute after reset
    clock.advance(1000);
    // No error thrown = success
    assert.ok(true);
  });

  it('handles zero-delay timeouts', () => {
    const clock = new MockClock();
    let called = false;

    clock.setTimeout(() => { called = true; }, 0);
    assert.strictEqual(called, false);

    clock.advance(0);
    assert.strictEqual(called, true);
  });
});
