/**
 * Custom Reporter Tests
 * 
 * Validates SOA data structures and reporter output formatting.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createCustomReporter } from '../../src/reporters/custom-reporter.js';

// ============================================================================
// CUSTOM REPORTER TESTS
// ============================================================================

describe('Custom Reporter', { concurrency: 4 }, () => {
  it('creates reporter with default options', () => {
    const reporter = createCustomReporter();
    assert.ok(reporter instanceof Transform);
  });

  it('creates reporter with custom options', () => {
    const reporter = createCustomReporter({
      showTiming: false,
      showFiles: false,
      maxFailures: 5,
      colorize: false,
    });
    assert.ok(reporter instanceof Transform);
  });

  it('processes test pass events', (done) => {
    const reporter = createCustomReporter({ colorize: false });
    let output = '';

    reporter.on('data', (chunk: Buffer) => {
      output += chunk.toString();
    });

    reporter.on('end', () => {
      assert.ok(output.includes('Test Results'));
      assert.ok(output.includes('Passed:'));
      done();
    });

    reporter.write({
      type: 'test:pass',
      data: { name: 'test 1', file: 'test.ts', duration_ms: 10 },
    });
    reporter.end();
  });

  it('processes test fail events', (done) => {
    const reporter = createCustomReporter({ colorize: false });
    let output = '';

    reporter.on('data', (chunk: Buffer) => {
      output += chunk.toString();
    });

    reporter.on('end', () => {
      assert.ok(output.includes('Failures:'));
      assert.ok(output.includes('test 1'));
      done();
    });

    reporter.write({
      type: 'test:fail',
      data: { 
        name: 'test 1', 
        file: 'test.ts', 
        duration_ms: 5,
        error: new Error('test error'),
      },
    });
    reporter.end();
  });

  it('limits failure output', (done) => {
    const reporter = createCustomReporter({ 
      colorize: false, 
      maxFailures: 2 
    });
    let output = '';

    reporter.on('data', (chunk: Buffer) => {
      output += chunk.toString();
    });

    reporter.on('end', () => {
      assert.ok(output.includes('and 3 more failures'));
      done();
    });

    for (let i = 0; i < 5; i++) {
      reporter.write({
        type: 'test:fail',
        data: { 
          name: `test ${i}`, 
          file: 'test.ts',
          error: new Error(`error ${i}`),
        },
      });
    }
    reporter.end();
  });

  it('handles empty test suite', (done) => {
    const reporter = createCustomReporter({ colorize: false });
    let output = '';

    reporter.on('data', (chunk: Buffer) => {
      output += chunk.toString();
    });

    reporter.on('end', () => {
      assert.ok(output.includes('Total:   0'));
      done();
    });

    reporter.end();
  });
});
