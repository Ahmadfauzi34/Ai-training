/**
 * Unit Tests for Core Test Runner Utilities
 * 
 * These tests validate:
 * - Epsilon-based floating point comparisons
 * - Strict assertions
 * - Test suite builder
 * - Benchmark utilities
 * - Memory leak detection
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_EPSILON,
  nearEqual,
  nearEqualRelative,
  nearEqualUlp,
  StrictAssertions,
  TestSuite,
  benchmark,
  MemoryLeakDetector,
} from '../../src/core/index.js';

// ============================================================================
// EPSILON-BASED FLOATING POINT TESTS
// ============================================================================

describe('nearEqual', { concurrency: 4 }, () => {
  it('returns true for identical values', () => {
    assert.strictEqual(nearEqual(1.0, 1.0), true);
    assert.strictEqual(nearEqual(0.0, 0.0), true);
    assert.strictEqual(nearEqual(-5.5, -5.5), true);
  });

  it('returns true for values within epsilon', () => {
    assert.strictEqual(nearEqual(1.0, 1.0 + DEFAULT_EPSILON / 2), true);
    assert.strictEqual(nearEqual(100.0, 100.0 + DEFAULT_EPSILON * 10), true);
  });

  it('returns false for values outside epsilon', () => {
    assert.strictEqual(nearEqual(1.0, 2.0), false);
    assert.strictEqual(nearEqual(0.0, DEFAULT_EPSILON * 10), false);
  });

  it('handles edge cases correctly', () => {
    assert.strictEqual(nearEqual(0.0, 0.0), true);
    assert.strictEqual(nearEqual(Number.MIN_VALUE, 0.0), true);
    assert.strictEqual(nearEqual(Infinity, Infinity), true);
    assert.strictEqual(nearEqual(-Infinity, -Infinity), true);
    assert.strictEqual(nearEqual(Infinity, -Infinity), false);
  });

  it('uses custom epsilon correctly', () => {
    assert.strictEqual(nearEqual(1.0, 1.5, 1.0), true);  // diff=0.5 <= 1.0
    assert.strictEqual(nearEqual(1.0, 1.5, 0.1), false); // diff=0.5 > 0.1
  });
});

describe('nearEqualRelative', { concurrency: 4 }, () => {
  it('compares large numbers relatively', () => {
    assert.strictEqual(nearEqualRelative(1e9, 1e9 + 1e2, 1e-6), true);
    assert.strictEqual(nearEqualRelative(1e9, 1e9 + 1e6, 1e-6), false);
  });

  it('handles small numbers near zero', () => {
    assert.strictEqual(nearEqualRelative(1e-10, 1e-10 + 1e-15, 1e-4), true);
  });

  it('uses scale of 1 for near-zero comparisons', () => {
    assert.strictEqual(nearEqualRelative(0.0, 1e-10, 1e-6), true);
  });
});

describe('nearEqualUlp', { concurrency: 4 }, () => {
  it('compares adjacent floating point values', () => {
    const a = 1.0;
    const b = Math.nextafter(a, 2.0);
    assert.strictEqual(nearEqualUlp(a, b, 1), true);
    assert.strictEqual(nearEqualUlp(a, b, 0), false);
  });

  it('handles NaN correctly', () => {
    assert.strictEqual(nearEqualUlp(NaN, NaN), true);
    assert.strictEqual(nearEqualUlp(NaN, 1.0), false);
  });

  it('handles infinity correctly', () => {
    assert.strictEqual(nearEqualUlp(Infinity, Infinity), true);
    assert.strictEqual(nearEqualUlp(-Infinity, -Infinity), true);
    assert.strictEqual(nearEqualUlp(Infinity, -Infinity), false);
  });
});

// ============================================================================
// STRICT ASSERTIONS TESTS
// ============================================================================

describe('StrictAssertions', { concurrency: 4 }, () => {
  describe('nearEqual', () => {
    it('passes for equal values', () => {
      StrictAssertions.nearEqual(1.0, 1.0);
      StrictAssertions.nearEqual(1.0, 1.0 + DEFAULT_EPSILON / 2);
    });

    it('fails for unequal values', () => {
      assert.throws(
        () => StrictAssertions.nearEqual(1.0, 2.0),
        /Expected 2.*but got 1/
      );
    });

    it('uses custom message', () => {
      assert.throws(
        () => StrictAssertions.nearEqual(1.0, 2.0, DEFAULT_EPSILON, 'custom error'),
        /custom error/
      );
    });
  });

  describe('arrayNearEqual', () => {
    it('passes for equal arrays', () => {
      StrictAssertions.arrayNearEqual([1.0, 2.0, 3.0], [1.0, 2.0, 3.0]);
    });

    it('passes for arrays within epsilon', () => {
      StrictAssertions.arrayNearEqual(
        [1.0, 2.0 + DEFAULT_EPSILON / 2, 3.0],
        [1.0, 2.0, 3.0]
      );
    });

    it('fails for length mismatch', () => {
      assert.throws(
        () => StrictAssertions.arrayNearEqual([1.0], [1.0, 2.0]),
        /Array length mismatch/
      );
    });

    it('fails for value mismatch', () => {
      assert.throws(
        () => StrictAssertions.arrayNearEqual([1.0, 5.0], [1.0, 2.0]),
        /Array mismatch at index 1/
      );
    });

    it('handles large arrays efficiently', () => {
      const size = 1000;
      const a = new Array(size).fill(0).map((_, i) => i * 0.1);
      const b = a.map(x => x + DEFAULT_EPSILON / 2);
      StrictAssertions.arrayNearEqual(a, b);
    });
  });

  describe('inRange', () => {
    it('passes for values in range', () => {
      StrictAssertions.inRange(5, 0, 10);
      StrictAssertions.inRange(0, 0, 10);
      StrictAssertions.inRange(10, 0, 10);
    });

    it('fails for values out of range', () => {
      assert.throws(() => StrictAssertions.inRange(-1, 0, 10));
      assert.throws(() => StrictAssertions.inRange(11, 0, 10));
    });
  });

  describe('throws', () => {
    it('passes for thrown errors', () => {
      StrictAssertions.throws(() => { throw new Error('test'); });
      StrictAssertions.throws(() => { throw new Error('test'); }, /test/);
      StrictAssertions.throws(() => { throw new TypeError('test'); }, TypeError);
    });

    it('fails when no error thrown', () => {
      assert.throws(() => StrictAssertions.throws(() => {}));
    });
  });

  describe('resolvesWithin', () => {
    it('passes for fast promises', async () => {
      const result = await StrictAssertions.resolvesWithin(
        Promise.resolve(42),
        1000
      );
      assert.strictEqual(result, 42);
    });

    it('fails for slow promises', async () => {
      await assert.rejects(
        StrictAssertions.resolvesWithin(
          new Promise(r => setTimeout(r, 100)),
          10
        ),
        /did not resolve within/
      );
    });
  });

  describe('deepStrictEqual', () => {
    it('passes for deeply equal objects', () => {
      StrictAssertions.deepStrictEqual({ a: 1, b: [2, 3] }, { a: 1, b: [2, 3] });
    });

    it('fails for different objects', () => {
      assert.throws(() => 
        StrictAssertions.deepStrictEqual({ a: 1 }, { a: 2 })
      );
    });
  });

  describe('strictEqual', () => {
    it('passes for identical references', () => {
      const obj = { a: 1 };
      StrictAssertions.strictEqual(obj, obj);
    });

    it('fails for different references with same content', () => {
      assert.throws(() => 
        StrictAssertions.strictEqual({ a: 1 }, { a: 1 })
      );
    });
  });

  describe('defined', () => {
    it('passes for defined values', () => {
      StrictAssertions.defined(0);
      StrictAssertions.defined('');
      StrictAssertions.defined(false);
      StrictAssertions.defined({});
    });

    it('fails for null', () => {
      assert.throws(() => StrictAssertions.defined(null));
    });

    it('fails for undefined', () => {
      assert.throws(() => StrictAssertions.defined(undefined));
    });
  });

  describe('matches', () => {
    it('passes for matching strings', () => {
      StrictAssertions.matches('hello world', /world/);
      StrictAssertions.matches('test@email.com', /^[^@]+@[^@]+$/);
    });

    it('fails for non-matching strings', () => {
      assert.throws(() => 
        StrictAssertions.matches('hello', /world/)
      );
    });
  });
});

// ============================================================================
// TEST SUITE BUILDER TESTS
// ============================================================================

describe('TestSuite', { concurrency: 4 }, () => {
  it('builds a simple test suite', () => {
    const suite = new TestSuite({ name: 'simple suite' });
    suite.test('simple test', () => {
      assert.strictEqual(1 + 1, 2);
    });
    // Build would register with node:test describe/it
    // We verify the suite was constructed without errors
    assert.strictEqual(suite instanceof TestSuite, true);
  });

  it('supports hook chaining', () => {
    const suite = new TestSuite({ name: 'hook suite' });
    let callOrder: string[] = [];

    suite
      .before(() => { callOrder.push('before'); })
      .beforeEach(() => { callOrder.push('beforeEach'); })
      .afterEach(() => { callOrder.push('afterEach'); })
      .after(() => { callOrder.push('after'); })
      .test('hook test', () => { callOrder.push('test'); });

    // Verify hooks were registered
    assert.strictEqual(suite instanceof TestSuite, true);
  });

  it('supports configuration options', () => {
    const suite = new TestSuite({
      name: 'configured suite',
      concurrency: 2,
      timeout: 5000,
    });
    suite.test('configured test', () => {});
    assert.strictEqual(suite instanceof TestSuite, true);
  });
});

// ============================================================================
// BENCHMARK UTILITIES TESTS
// ============================================================================

describe('benchmark', { concurrency: 4 }, () => {
  it('measures simple operations', () => {
    const result = benchmark('addition', () => {
      const x = 1 + 1;
    }, 1000);

    assert.strictEqual(result.name, 'addition');
    assert.strictEqual(result.iterations, 1000);
    assert.ok(result.totalMs >= 0);
    assert.ok(result.meanMs >= 0);
    assert.ok(result.minMs >= 0);
    assert.ok(result.maxMs >= result.minMs);
    assert.ok(result.opsPerSecond > 0);
  });

  it('measures array operations', () => {
    const arr = new Array(100).fill(0);
    const result = benchmark('array sum', () => {
      let sum = 0;
      for (let i = 0; i < arr.length; i++) {
        sum += arr[i];
      }
    }, 10000);

    assert.strictEqual(result.iterations, 10000);
    assert.ok(result.opsPerSecond > 0);
  });

  it('handles default iteration count', () => {
    const result = benchmark('default', () => {});
    assert.strictEqual(result.iterations, 100000);
  });
});

// ============================================================================
// MEMORY LEAK DETECTOR TESTS
// ============================================================================

describe('MemoryLeakDetector', { concurrency: 2 }, () => {
  it('detects no leak for stable memory', () => {
    const detector = new MemoryLeakDetector(1024 * 1024); // 1MB threshold
    detector.start();

    // Stable operation
    const arr = [1, 2, 3];
    detector.check('stable operation');

    // Should not throw
    assert.ok(true);
  });

  it('has reasonable threshold defaults', () => {
    const detector = new MemoryLeakDetector();
    assert.strictEqual(detector instanceof MemoryLeakDetector, true);
  });

  it('snapshots memory usage', () => {
    const detector = new MemoryLeakDetector();
    const baseline = detector.snapshot();

    assert.ok(typeof baseline === 'number');
    assert.ok(baseline > 0);
  });
});

// ============================================================================
// INTEGRATION: Full assertion pipeline
// ============================================================================

describe('Full Assertion Pipeline', { concurrency: 4 }, () => {
  it('validates numeric computation pipeline', () => {
    // Simulate a computation pipeline
    const input = [1.0, 2.0, 3.0, 4.0, 5.0];
    const expected = [2.0, 4.0, 6.0, 8.0, 10.0];

    // Transform: multiply by 2
    const actual = input.map(x => x * 2.0);

    // Validate with epsilon
    StrictAssertions.arrayNearEqual(actual, expected);

    // Validate each element is in expected range
    for (const val of actual) {
      StrictAssertions.inRange(val, 0, 20);
    }

    // Validate sum
    const sum = actual.reduce((a, b) => a + b, 0);
    StrictAssertions.nearEqual(sum, 30.0);
  });

  it('validates async pipeline with timeout', async () => {
    const asyncOperation = async () => {
      return new Promise<number>(resolve => {
        setTimeout(() => resolve(42), 10);
      });
    };

    const result = await StrictAssertions.resolvesWithin(asyncOperation(), 1000);
    StrictAssertions.strictEqual(result, 42);
  });

  it('validates error handling pipeline', () => {
    const riskyOperation = (shouldFail: boolean) => {
      if (shouldFail) {
        throw new Error('Intentional failure');
      }
      return 'success';
    };

    // Should throw
    StrictAssertions.throws(() => riskyOperation(true), /Intentional failure/);

    // Should not throw
    const result = riskyOperation(false);
    StrictAssertions.defined(result);
    StrictAssertions.matches(result, /success/);
  });
});
