/**
 * Fixture Utilities Tests
 * 
 * Validates pre-allocated fixture pool and deterministic data generation.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  createFixture,
  createTempFile,
  SeededRandom,
  assertFileExists,
  assertFileContains,
  assertDirectoryExists,
} from '../../src/utils/fixture.js';
import { existsSync, readFileSync } from 'node:fs';

// ============================================================================
// FIXTURE CONTEXT TESTS
// ============================================================================

describe('createFixture', { concurrency: 2 }, () => {
  it('creates fixture directory', () => {
    const fixture = createFixture();

    assert.ok(existsSync(fixture.path));
    assertDirectoryExists(fixture.path);

    fixture.cleanup();
  });

  it('writes files to fixture', () => {
    const fixture = createFixture();

    fixture.writeFile('test.txt', 'hello world');
    assertFileExists(`${fixture.path}/test.txt`);
    assertFileContains(`${fixture.path}/test.txt`, 'hello');

    fixture.cleanup();
  });

  it('writes JSON files', () => {
    const fixture = createFixture();
    const data = { name: 'test', value: 42 };

    fixture.writeJSON('config.json', data);

    const content = readFileSync(`${fixture.path}/config.json`, 'utf-8');
    const parsed = JSON.parse(content);

    assert.deepStrictEqual(parsed, data);
    fixture.cleanup();
  });

  it('creates subdirectories', () => {
    const fixture = createFixture();

    const subDir = fixture.mkdir('subdirectory');
    assertDirectoryExists(subDir);

    fixture.writeFile('subdirectory/nested.txt', 'nested content');
    assertFileExists(`${subDir}/nested.txt`);

    fixture.cleanup();
  });

  it('cleans up after use', () => {
    const fixture = createFixture();
    const path = fixture.path;

    fixture.writeFile('temp.txt', 'temp');
    fixture.cleanup();

    // Directory should be removed
    assert.strictEqual(existsSync(`${path}/temp.txt`), false);
  });

  it('supports nested paths in writeFile', () => {
    const fixture = createFixture();

    fixture.writeFile('deep/nested/path/file.txt', 'deep content');
    assertFileExists(`${fixture.path}/deep/nested/path/file.txt`);

    fixture.cleanup();
  });
});

// ============================================================================
// TEMP FILE TESTS
// ============================================================================

describe('createTempFile', { concurrency: 2 }, () => {
  it('creates temp file with extension', () => {
    const temp = createTempFile('.json');

    assert.ok(temp.path.endsWith('.json'));
    assert.ok(existsSync(temp.path) === false); // Not created yet

    temp.write('{"test": true}');
    assertFileExists(temp.path);

    temp.cleanup();
  });

  it('writes and reads binary data', () => {
    const temp = createTempFile('.bin');
    const data = Buffer.from([0x00, 0x01, 0x02, 0x03]);

    temp.write(data);
    const read = temp.read();

    assert.ok(Buffer.isBuffer(read));
    assert.deepStrictEqual(read, data);

    temp.cleanup();
  });

  it('cleans up temp file', () => {
    const temp = createTempFile('.txt');
    temp.write('cleanup test');
    const path = temp.path;

    temp.cleanup();
    assert.strictEqual(existsSync(path), false);
  });
});

// ============================================================================
// SEEDED RANDOM TESTS
// ============================================================================

describe('SeededRandom', { concurrency: 4 }, () => {
  it('generates deterministic sequence', () => {
    const rng1 = new SeededRandom(42);
    const rng2 = new SeededRandom(42);

    const seq1 = [rng1.next(), rng1.next(), rng1.next()];
    const seq2 = [rng2.next(), rng2.next(), rng2.next()];

    assert.deepStrictEqual(seq1, seq2);
  });

  it('generates different sequences with different seeds', () => {
    const rng1 = new SeededRandom(1);
    const rng2 = new SeededRandom(2);

    const v1 = rng1.next();
    const v2 = rng2.next();

    assert.notStrictEqual(v1, v2);
  });

  it('generates integers in range', () => {
    const rng = new SeededRandom(123);

    for (let i = 0; i < 100; i++) {
      const val = rng.nextInt(10, 20);
      assert.ok(val >= 10 && val <= 20, `Value ${val} out of range [10, 20]`);
    }
  });

  it('generates floats in range', () => {
    const rng = new SeededRandom(456);

    for (let i = 0; i < 100; i++) {
      const val = rng.nextFloat(-1, 1);
      assert.ok(val >= -1 && val <= 1, `Value ${val} out of range [-1, 1]`);
    }
  });

  it('generates boolean values', () => {
    const rng = new SeededRandom(789);
    let trueCount = 0;

    for (let i = 0; i < 1000; i++) {
      if (rng.nextBool()) trueCount++;
    }

    // Should be roughly 50/50 (within 10%)
    assert.ok(trueCount > 400 && trueCount < 600,
      `True count ${trueCount} not in expected range`);
  });

  it('generates float arrays', () => {
    const rng = new SeededRandom(999);
    const arr = rng.floatArray(100, 0, 1);

    assert.strictEqual(arr.length, 100);
    assert.ok(arr instanceof Float64Array);

    for (let i = 0; i < arr.length; i++) {
      assert.ok(arr[i] >= 0 && arr[i] <= 1);
    }
  });

  it('generates random strings', () => {
    const rng = new SeededRandom(111);
    const str = rng.string(20);

    assert.strictEqual(str.length, 20);
    assert.ok(/^[a-z]+$/.test(str));
  });

  it('generates different strings', () => {
    const rng = new SeededRandom(222);
    const str1 = rng.string(10);
    const str2 = rng.string(10);

    assert.notStrictEqual(str1, str2);
  });
});

// ============================================================================
// ASSERTION HELPERS TESTS
// ============================================================================

describe('fixture assertion helpers', { concurrency: 4 }, () => {
  it('assertFileExists passes for existing file', () => {
    const fixture = createFixture();
    fixture.writeFile('exists.txt', 'content');

    // Should not throw
    assertFileExists(`${fixture.path}/exists.txt`);

    fixture.cleanup();
  });

  it('assertFileExists throws for missing file', () => {
    assert.throws(() => {
      assertFileExists('/nonexistent/path/file.txt');
    }, /Expected file to exist/);
  });

  it('assertFileContains passes for matching content', () => {
    const fixture = createFixture();
    fixture.writeFile('content.txt', 'hello world');

    // Should not throw
    assertFileContains(`${fixture.path}/content.txt`, 'world');

    fixture.cleanup();
  });

  it('assertFileContains throws for missing content', () => {
    const fixture = createFixture();
    fixture.writeFile('content.txt', 'hello world');

    assert.throws(() => {
      assertFileContains(`${fixture.path}/content.txt`, 'missing');
    }, /Expected file.*to contain/);

    fixture.cleanup();
  });

  it('assertDirectoryExists passes for directory', () => {
    const fixture = createFixture();

    // Should not throw
    assertDirectoryExists(fixture.path);

    fixture.cleanup();
  });

  it('assertDirectoryExists throws for file', () => {
    const fixture = createFixture();
    fixture.writeFile('file.txt', 'content');

    assert.throws(() => {
      assertDirectoryExists(`${fixture.path}/file.txt`);
    });

    fixture.cleanup();
  });
});
