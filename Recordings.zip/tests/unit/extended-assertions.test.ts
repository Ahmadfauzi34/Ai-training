/**
 * Extended Assertions Tests
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  CollectionAssertions,
  StringAssertions,
  NumericAssertions,
  DateAssertions,
  ErrorAssertions,
  NetworkAssertions,
} from '../../src/assertions/extended.js';

// ============================================================================
// COLLECTION ASSERTIONS TESTS
// ============================================================================

describe('CollectionAssertions', { concurrency: 4 }, () => {
  it('isSorted passes for sorted array', () => {
    CollectionAssertions.isSorted([1, 2, 3, 4, 5]);
    CollectionAssertions.isSorted(['a', 'b', 'c']);
  });

  it('isSorted throws for unsorted array', () => {
    assert.throws(() => CollectionAssertions.isSorted([3, 1, 2]));
  });

  it('isSorted handles empty and single-element arrays', () => {
    CollectionAssertions.isSorted([]);
    CollectionAssertions.isSorted([42]);
  });

  it('hasNoDuplicates passes for unique array', () => {
    CollectionAssertions.hasNoDuplicates([1, 2, 3, 4, 5]);
  });

  it('hasNoDuplicates throws for duplicate array', () => {
    assert.throws(() => CollectionAssertions.hasNoDuplicates([1, 2, 2, 3]));
  });

  it('containsExactly passes for matching arrays', () => {
    CollectionAssertions.containsExactly([1, 2, 3], [3, 2, 1]);
    CollectionAssertions.containsExactly(['a', 'b'], ['b', 'a']);
  });

  it('containsExactly throws for different lengths', () => {
    assert.throws(() => CollectionAssertions.containsExactly([1, 2], [1, 2, 3]));
  });

  it('containsExactly throws for different elements', () => {
    assert.throws(() => CollectionAssertions.containsExactly([1, 2], [1, 3]));
  });

  it('isEmpty passes for empty array', () => {
    CollectionAssertions.isEmpty([]);
  });

  it('isEmpty throws for non-empty array', () => {
    assert.throws(() => CollectionAssertions.isEmpty([1]));
  });

  it('isNotEmpty passes for non-empty array', () => {
    CollectionAssertions.isNotEmpty([1]);
  });

  it('isNotEmpty throws for empty array', () => {
    assert.throws(() => CollectionAssertions.isNotEmpty([]));
  });

  it('allMatch passes when all match', () => {
    CollectionAssertions.allMatch([2, 4, 6, 8], x => x % 2 === 0);
  });

  it('allMatch throws when one fails', () => {
    assert.throws(() => CollectionAssertions.allMatch([2, 4, 5, 8], x => x % 2 === 0));
  });

  it('anyMatch passes when at least one matches', () => {
    CollectionAssertions.anyMatch([1, 3, 5, 8], x => x % 2 === 0);
  });

  it('anyMatch throws when none match', () => {
    assert.throws(() => CollectionAssertions.anyMatch([1, 3, 5, 7], x => x % 2 === 0));
  });
});

// ============================================================================
// STRING ASSERTIONS TESTS
// ============================================================================

describe('StringAssertions', { concurrency: 4 }, () => {
  it('startsWith passes for matching prefix', () => {
    StringAssertions.startsWith('hello world', 'hello');
  });

  it('startsWith throws for non-matching prefix', () => {
    assert.throws(() => StringAssertions.startsWith('hello', 'world'));
  });

  it('endsWith passes for matching suffix', () => {
    StringAssertions.endsWith('hello world', 'world');
  });

  it('endsWith throws for non-matching suffix', () => {
    assert.throws(() => StringAssertions.endsWith('hello', 'world'));
  });

  it('contains passes for matching substring', () => {
    StringAssertions.contains('hello world', 'lo wo');
  });

  it('contains throws for missing substring', () => {
    assert.throws(() => StringAssertions.contains('hello', 'xyz'));
  });

  it('matches passes for matching regex', () => {
    StringAssertions.matches('hello123', /^[a-z]+\d+$/);
  });

  it('matches throws for non-matching regex', () => {
    assert.throws(() => StringAssertions.matches('hello', /^\d+$/));
  });

  it('isValidJSON passes for valid JSON', () => {
    StringAssertions.isValidJSON('{"key": "value"}');
    StringAssertions.isValidJSON('[1, 2, 3]');
    StringAssertions.isValidJSON('"string"');
  });

  it('isValidJSON throws for invalid JSON', () => {
    assert.throws(() => StringAssertions.isValidJSON('not json'));
    assert.throws(() => StringAssertions.isValidJSON('{invalid}'));
  });

  it('hasLength passes for correct length', () => {
    StringAssertions.hasLength('hello', 5);
  });

  it('hasLength throws for wrong length', () => {
    assert.throws(() => StringAssertions.hasLength('hello', 3));
  });

  it('isNotBlank passes for non-empty string', () => {
    StringAssertions.isNotBlank('hello');
    StringAssertions.isNotBlank('  x  ');
  });

  it('isNotBlank throws for blank string', () => {
    assert.throws(() => StringAssertions.isNotBlank(''));
    assert.throws(() => StringAssertions.isNotBlank('   '));
  });
});

// ============================================================================
// NUMERIC ASSERTIONS TESTS
// ============================================================================

describe('NumericAssertions', { concurrency: 4 }, () => {
  it('isInteger passes for integers', () => {
    NumericAssertions.isInteger(42);
    NumericAssertions.isInteger(0);
    NumericAssertions.isInteger(-5);
  });

  it('isInteger throws for floats', () => {
    assert.throws(() => NumericAssertions.isInteger(3.14));
  });

  it('isFinite passes for finite numbers', () => {
    NumericAssertions.isFinite(42);
    NumericAssertions.isFinite(0);
  });

  it('isFinite throws for Infinity', () => {
    assert.throws(() => NumericAssertions.isFinite(Infinity));
    assert.throws(() => NumericAssertions.isFinite(-Infinity));
  });

  it('isFinite throws for NaN', () => {
    assert.throws(() => NumericAssertions.isFinite(NaN));
  });

  it('isPositive passes for positive numbers', () => {
    NumericAssertions.isPositive(1);
    NumericAssertions.isPositive(0.001);
  });

  it('isPositive throws for zero and negative', () => {
    assert.throws(() => NumericAssertions.isPositive(0));
    assert.throws(() => NumericAssertions.isPositive(-1));
  });

  it('isNegative passes for negative numbers', () => {
    NumericAssertions.isNegative(-1);
    NumericAssertions.isNegative(-0.001);
  });

  it('isNegative throws for zero and positive', () => {
    assert.throws(() => NumericAssertions.isNegative(0));
    assert.throws(() => NumericAssertions.isNegative(1));
  });

  it('inRange passes for numbers in range', () => {
    NumericAssertions.inRange(5, 0, 10);
    NumericAssertions.inRange(0, 0, 10);
    NumericAssertions.inRange(10, 0, 10);
  });

  it('inRange throws for out of range', () => {
    assert.throws(() => NumericAssertions.inRange(-1, 0, 10));
    assert.throws(() => NumericAssertions.inRange(11, 0, 10));
  });

  it('near passes for close numbers', () => {
    NumericAssertions.near(1.0001, 1.0, 0.001);
  });

  it('near throws for distant numbers', () => {
    assert.throws(() => NumericAssertions.near(2.0, 1.0, 0.001));
  });

  it('isPercentage passes for valid percentages', () => {
    NumericAssertions.isPercentage(0);
    NumericAssertions.isPercentage(50);
    NumericAssertions.isPercentage(100);
  });

  it('isPercentage throws for invalid percentages', () => {
    assert.throws(() => NumericAssertions.isPercentage(-1));
    assert.throws(() => NumericAssertions.isPercentage(101));
  });
});

// ============================================================================
// DATE ASSERTIONS TESTS
// ============================================================================

describe('DateAssertions', { concurrency: 4 }, () => {
  it('isValid passes for valid dates', () => {
    DateAssertions.isValid(new Date());
    DateAssertions.isValid(new Date('2024-01-01'));
  });

  it('isValid throws for invalid dates', () => {
    assert.throws(() => DateAssertions.isValid(new Date('invalid')));
  });

  it('isBefore passes for earlier date', () => {
    const earlier = new Date('2024-01-01');
    const later = new Date('2024-12-31');
    DateAssertions.isBefore(earlier, later);
  });

  it('isBefore throws for later or equal date', () => {
    const date = new Date('2024-06-15');
    assert.throws(() => DateAssertions.isBefore(date, date));
    assert.throws(() => DateAssertions.isBefore(new Date('2024-12-31'), new Date('2024-01-01')));
  });

  it('isAfter passes for later date', () => {
    const later = new Date('2024-12-31');
    const earlier = new Date('2024-01-01');
    DateAssertions.isAfter(later, earlier);
  });

  it('near passes for close dates', () => {
    const d1 = new Date('2024-01-01T12:00:00.000Z');
    const d2 = new Date('2024-01-01T12:00:00.500Z');
    DateAssertions.near(d1, d2, 1000);
  });

  it('near throws for distant dates', () => {
    const d1 = new Date('2024-01-01');
    const d2 = new Date('2024-01-02');
    assert.throws(() => DateAssertions.near(d1, d2, 1000));
  });
});

// ============================================================================
// ERROR ASSERTIONS TESTS
// ============================================================================

describe('ErrorAssertions', { concurrency: 4 }, () => {
  it('hasMessage passes for string match', () => {
    ErrorAssertions.hasMessage(new Error('test error'), 'test');
  });

  it('hasMessage passes for regex match', () => {
    ErrorAssertions.hasMessage(new Error('test error'), /error$/);
  });

  it('hasMessage throws for non-matching message', () => {
    assert.throws(() => ErrorAssertions.hasMessage(new Error('foo'), 'bar'));
  });

  it('isType passes for matching type', () => {
    ErrorAssertions.isType(new TypeError('test'), TypeError);
    ErrorAssertions.isType(new RangeError('test'), RangeError);
  });

  it('isType throws for wrong type', () => {
    assert.throws(() => ErrorAssertions.isType(new Error('test'), TypeError));
  });

  it('hasCode passes for matching code', () => {
    const err = new Error('test') as NodeJS.ErrnoException;
    err.code = 'ENOENT';
    ErrorAssertions.hasCode(err, 'ENOENT');
  });

  it('hasCode throws for wrong code', () => {
    const err = new Error('test') as NodeJS.ErrnoException;
    err.code = 'ENOENT';
    assert.throws(() => ErrorAssertions.hasCode(err, 'EACCES'));
  });
});

// ============================================================================
// NETWORK ASSERTIONS TESTS
// ============================================================================

describe('NetworkAssertions', { concurrency: 4 }, () => {
  it('isValidURL passes for valid URLs', () => {
    NetworkAssertions.isValidURL('https://example.com');
    NetworkAssertions.isValidURL('http://localhost:3000');
    NetworkAssertions.isValidURL('ftp://files.example.com');
  });

  it('isValidURL throws for invalid URLs', () => {
    assert.throws(() => NetworkAssertions.isValidURL('not a url'));
    assert.throws(() => NetworkAssertions.isValidURL(''));
  });

  it('isValidEmail passes for valid emails', () => {
    NetworkAssertions.isValidEmail('test@example.com');
    NetworkAssertions.isValidEmail('user.name@domain.co.uk');
  });

  it('isValidEmail throws for invalid emails', () => {
    assert.throws(() => NetworkAssertions.isValidEmail('not-an-email'));
    assert.throws(() => NetworkAssertions.isValidEmail('@example.com'));
  });

  it('isValidIPv4 passes for valid IPs', () => {
    NetworkAssertions.isValidIPv4('192.168.1.1');
    NetworkAssertions.isValidIPv4('0.0.0.0');
    NetworkAssertions.isValidIPv4('255.255.255.255');
  });

  it('isValidIPv4 throws for invalid IPs', () => {
    assert.throws(() => NetworkAssertions.isValidIPv4('256.1.1.1'));
    assert.throws(() => NetworkAssertions.isValidIPv4('192.168.1'));
    assert.throws(() => NetworkAssertions.isValidIPv4('abc.def.ghi.jkl'));
  });
});
