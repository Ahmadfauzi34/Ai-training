/**
 * Math Utilities Tests
 * 
 * Demonstrates strict testing patterns for numerical computations
 * with epsilon-based assertions and performance benchmarks.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  nearEqual,
  nearEqualRelative,
  StrictAssertions,
  benchmark,
} from '../../src/core/index.js';

// ============================================================================
// VECTOR OPERATIONS
// ============================================================================

interface Vector2D {
  x: number;
  y: number;
}

function addVectors(a: Vector2D, b: Vector2D): Vector2D {
  return { x: a.x + b.x, y: a.y + b.y };
}

function dotProduct(a: Vector2D, b: Vector2D): number {
  return a.x * b.x + a.y * b.y;
}

function vectorLength(v: Vector2D): number {
  return Math.sqrt(v.x * v.x + v.y * v.y);
}

function normalize(v: Vector2D): Vector2D {
  const len = vectorLength(v);
  if (len === 0) return { x: 0, y: 0 };
  return { x: v.x / len, y: v.y / len };
}

// ============================================================================
// MATRIX OPERATIONS (2x2)
// ============================================================================

type Matrix2x2 = [number, number, number, number]; // [a, b, c, d] = [[a, b], [c, d]]

function multiplyMatrix(a: Matrix2x2, b: Matrix2x2): Matrix2x2 {
  return [
    a[0] * b[0] + a[1] * b[2],
    a[0] * b[1] + a[1] * b[3],
    a[2] * b[0] + a[3] * b[2],
    a[2] * b[1] + a[3] * b[3],
  ];
}

function determinant(m: Matrix2x2): number {
  return m[0] * m[3] - m[1] * m[2];
}

function inverseMatrix(m: Matrix2x2): Matrix2x2 | null {
  const det = determinant(m);
  if (nearEqual(det, 0, 1e-10)) return null;

  const invDet = 1.0 / det;
  return [
     m[3] * invDet, -m[1] * invDet,
    -m[2] * invDet,  m[0] * invDet,
  ];
}

// ============================================================================
// TESTS: Vector Operations
// ============================================================================

describe('Vector2D Operations', { concurrency: 4 }, () => {
  it('adds vectors correctly', () => {
    const a: Vector2D = { x: 1.0, y: 2.0 };
    const b: Vector2D = { x: 3.0, y: 4.0 };
    const result = addVectors(a, b);

    StrictAssertions.nearEqual(result.x, 4.0);
    StrictAssertions.nearEqual(result.y, 6.0);
  });

  it('computes dot product correctly', () => {
    const a: Vector2D = { x: 1.0, y: 2.0 };
    const b: Vector2D = { x: 3.0, y: 4.0 };
    const result = dotProduct(a, b);

    // 1*3 + 2*4 = 11
    StrictAssertions.nearEqual(result, 11.0);
  });

  it('computes vector length correctly', () => {
    const v: Vector2D = { x: 3.0, y: 4.0 };
    const result = vectorLength(v);

    // sqrt(9 + 16) = 5
    StrictAssertions.nearEqual(result, 5.0);
  });

  it('normalizes vectors to unit length', () => {
    const v: Vector2D = { x: 3.0, y: 4.0 };
    const result = normalize(v);
    const len = vectorLength(result);

    // Should be exactly 1.0 (or very close)
    StrictAssertions.nearEqual(len, 1.0, 1e-15);
    StrictAssertions.nearEqual(result.x, 0.6);
    StrictAssertions.nearEqual(result.y, 0.8);
  });

  it('handles zero vector normalization', () => {
    const v: Vector2D = { x: 0.0, y: 0.0 };
    const result = normalize(v);

    StrictAssertions.nearEqual(result.x, 0.0);
    StrictAssertions.nearEqual(result.y, 0.0);
  });

  it('validates vector operations with floating point', () => {
    const v: Vector2D = { x: 1.0 / 3.0, y: 2.0 / 3.0 };
    const len = vectorLength(v);

    // sqrt((1/9) + (4/9)) = sqrt(5/9) = sqrt(5)/3
    const expected = Math.sqrt(5.0) / 3.0;
    StrictAssertions.nearEqual(len, expected);
  });
});

// ============================================================================
// TESTS: Matrix Operations
// ============================================================================

describe('Matrix2x2 Operations', { concurrency: 4 }, () => {
  it('multiplies identity matrix correctly', () => {
    const identity: Matrix2x2 = [1, 0, 0, 1];
    const m: Matrix2x2 = [2, 3, 4, 5];

    const result = multiplyMatrix(identity, m);
    StrictAssertions.arrayNearEqual(result, m);

    const result2 = multiplyMatrix(m, identity);
    StrictAssertions.arrayNearEqual(result2, m);
  });

  it('multiplies matrices correctly', () => {
    const a: Matrix2x2 = [1, 2, 3, 4];
    const b: Matrix2x2 = [5, 6, 7, 8];
    const result = multiplyMatrix(a, b);

    // [1*5+2*7, 1*6+2*8, 3*5+4*7, 3*6+4*8]
    // = [19, 22, 43, 50]
    const expected: Matrix2x2 = [19, 22, 43, 50];
    StrictAssertions.arrayNearEqual(result, expected);
  });

  it('computes determinant correctly', () => {
    const m: Matrix2x2 = [1, 2, 3, 4];
    const det = determinant(m);

    // 1*4 - 2*3 = -2
    StrictAssertions.nearEqual(det, -2.0);
  });

  it('computes inverse correctly', () => {
    const m: Matrix2x2 = [4, 7, 2, 6];
    const inv = inverseMatrix(m);

    assert.ok(inv !== null, 'Inverse should exist');
    if (inv) {
      // det = 4*6 - 7*2 = 24 - 14 = 10
      // inv = [0.6, -0.7, -0.2, 0.4]
      StrictAssertions.nearEqual(inv[0], 0.6);
      StrictAssertions.nearEqual(inv[1], -0.7);
      StrictAssertions.nearEqual(inv[2], -0.2);
      StrictAssertions.nearEqual(inv[3], 0.4);

      // Verify: m * inv = identity
      const product = multiplyMatrix(m, inv);
      const identity: Matrix2x2 = [1, 0, 0, 1];
      StrictAssertions.arrayNearEqual(product, identity, 1e-14);
    }
  });

  it('returns null for singular matrix', () => {
    const singular: Matrix2x2 = [1, 2, 2, 4]; // det = 0
    const inv = inverseMatrix(singular);

    assert.strictEqual(inv, null);
  });

  it('handles near-singular matrices with epsilon', () => {
    const nearSingular: Matrix2x2 = [1, 2, 2, 4 + 1e-12];
    const inv = inverseMatrix(nearSingular);

    // Very small determinant should still be invertible
    assert.ok(inv !== null);
    if (inv) {
      const product = multiplyMatrix(nearSingular, inv);
      const identity: Matrix2x2 = [1, 0, 0, 1];
      StrictAssertions.arrayNearEqual(product, identity, 1e-8);
    }
  });
});

// ============================================================================
// TESTS: Performance Benchmarks
// ============================================================================

describe('Performance Benchmarks', { concurrency: 2 }, () => {
  it('benchmarks vector addition', () => {
    const v1: Vector2D = { x: 1.0, y: 2.0 };
    const v2: Vector2D = { x: 3.0, y: 4.0 };

    const result = benchmark('vector addition', () => {
      addVectors(v1, v2);
    }, 100000);

    // Should be very fast (millions of ops/sec)
    assert.ok(result.opsPerSecond > 100000, 
      `Expected > 100k ops/sec, got ${result.opsPerSecond.toFixed(0)}`);

    // Variance should be reasonable
    const variance = result.maxMs - result.minMs;
    assert.ok(variance < result.meanMs * 10, 
      `High variance detected: ${variance.toFixed(4)}ms`);
  });

  it('benchmarks matrix multiplication', () => {
    const a: Matrix2x2 = [1, 2, 3, 4];
    const b: Matrix2x2 = [5, 6, 7, 8];

    const result = benchmark('matrix multiply', () => {
      multiplyMatrix(a, b);
    }, 50000);

    assert.ok(result.opsPerSecond > 50000,
      `Expected > 50k ops/sec, got ${result.opsPerSecond.toFixed(0)}`);
  });

  it('benchmarks dot product', () => {
    const v1: Vector2D = { x: 1.0, y: 2.0 };
    const v2: Vector2D = { x: 3.0, y: 4.0 };

    const result = benchmark('dot product', () => {
      dotProduct(v1, v2);
    }, 100000);

    assert.ok(result.opsPerSecond > 100000,
      `Expected > 100k ops/sec, got ${result.opsPerSecond.toFixed(0)}`);
  });

  it('validates benchmark consistency', () => {
    // Run same benchmark multiple times
    const results: number[] = [];

    for (let i = 0; i < 5; i++) {
      const r = benchmark('consistency test', () => {
        let sum = 0;
        for (let j = 0; j < 10; j++) {
          sum += j;
        }
      }, 10000);
      results.push(r.meanMs);
    }

    // Results should be relatively consistent (within 50% of mean)
    const mean = results.reduce((a, b) => a + b, 0) / results.length;
    for (const r of results) {
      const deviation = Math.abs(r - mean) / mean;
      assert.ok(deviation < 0.5,
        `High deviation in benchmark: ${(deviation * 100).toFixed(1)}%`);
    }
  });
});

// ============================================================================
// TESTS: Edge Cases & Numerical Stability
// ============================================================================

describe('Numerical Stability', { concurrency: 4 }, () => {
  it('handles very small numbers', () => {
    const tiny: Vector2D = { x: 1e-300, y: 1e-300 };
    const len = vectorLength(tiny);

    // sqrt(2 * 1e-600) = sqrt(2) * 1e-300
    const expected = Math.sqrt(2) * 1e-300;
    StrictAssertions.nearEqual(len, expected, 1e-310);
  });

  it('handles very large numbers', () => {
    const huge: Vector2D = { x: 1e150, y: 1e150 };
    const len = vectorLength(huge);

    // Should not overflow to Infinity
    assert.ok(Number.isFinite(len), 'Length should be finite');

    const expected = Math.sqrt(2) * 1e150;
    StrictAssertions.nearEqualRelative(len, expected, 1e-10);
  });

  it('handles catastrophic cancellation', () => {
    // (1 + 1e-15) - 1 should be ~1e-15, not 0
    const a = 1.0 + 1e-15;
    const b = 1.0;
    const diff = a - b;

    // With default epsilon this might fail due to precision
    // Use relative comparison instead
    StrictAssertions.nearEqualRelative(diff, 1e-15, 1e-3);
  });

  it('validates associative property failure', () => {
    // Floating point: (a + b) + c != a + (b + c) in general
    const a = 0.1;
    const b = 0.2;
    const c = 0.3;

    const left = (a + b) + c;
    const right = a + (b + c);

    // They should be close but not exactly equal
    StrictAssertions.nearEqual(left, right);

    // But strict equality should fail
    assert.notStrictEqual(left, right);
  });

  it('handles NaN and Infinity correctly', () => {
    const nanVec: Vector2D = { x: NaN, y: 1.0 };
    const len = vectorLength(nanVec);

    assert.ok(Number.isNaN(len), 'Length of NaN vector should be NaN');

    const infVec: Vector2D = { x: Infinity, y: 0.0 };
    const infLen = vectorLength(infVec);

    assert.ok(!Number.isFinite(infLen), 'Length of infinite vector should be infinite');
  });
});
