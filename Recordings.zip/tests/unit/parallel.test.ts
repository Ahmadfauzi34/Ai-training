/**
 * Parallel Utilities Tests
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  parallelMap,
  parallelFilter,
  withTimeout,
  withDeadline,
  withRetry,
} from '../../src/utils/parallel.js';

// ============================================================================
// PARALLEL MAP TESTS
// ============================================================================

describe('parallelMap', { concurrency: 4 }, () => {
  it('maps array with async function', async () => {
    const items = [1, 2, 3, 4, 5];
    const results = await parallelMap(items, async (x) => x * 2);

    assert.deepStrictEqual(results, [2, 4, 6, 8, 10]);
  });

  it('preserves order', async () => {
    const items = ['a', 'b', 'c', 'd'];
    const results = await parallelMap(items, async (x) => x.toUpperCase());

    assert.deepStrictEqual(results, ['A', 'B', 'C', 'D']);
  });

  it('handles empty array', async () => {
    const results = await parallelMap([], async (x) => x);

    assert.deepStrictEqual(results, []);
  });

  it('handles single item', async () => {
    const results = await parallelMap([42], async (x) => x * 2);

    assert.deepStrictEqual(results, [84]);
  });

  it('handles errors', async () => {
    const items = [1, 2, 3];

    await assert.rejects(
      parallelMap(items, async (x) => {
        if (x === 2) throw new Error('test error');
        return x;
      }),
      /test error/
    );
  });

  it('respects concurrency limit', async () => {
    const concurrency = 2;
    let running = 0;
    let maxRunning = 0;

    const items = new Array(10).fill(0);

    await parallelMap(items, async () => {
      running++;
      maxRunning = Math.max(maxRunning, running);
      await new Promise(r => setTimeout(r, 50));
      running--;
      return 1;
    }, concurrency);

    assert.ok(maxRunning <= concurrency,
      `Max concurrent ${maxRunning} exceeded limit ${concurrency}`);
  });
});

// ============================================================================
// PARALLEL FILTER TESTS
// ============================================================================

describe('parallelFilter', { concurrency: 4 }, () => {
  it('filters array with async predicate', async () => {
    const items = [1, 2, 3, 4, 5, 6];
    const results = await parallelFilter(items, async (x) => x % 2 === 0);

    assert.deepStrictEqual(results, [2, 4, 6]);
  });

  it('returns empty array when nothing matches', async () => {
    const items = [1, 3, 5];
    const results = await parallelFilter(items, async (x) => x % 2 === 0);

    assert.deepStrictEqual(results, []);
  });

  it('returns all items when all match', async () => {
    const items = [2, 4, 6];
    const results = await parallelFilter(items, async (x) => x % 2 === 0);

    assert.deepStrictEqual(results, [2, 4, 6]);
  });
});

// ============================================================================
// TIMEOUT TESTS
// ============================================================================

describe('withTimeout', { concurrency: 4 }, () => {
  it('resolves when promise completes in time', async () => {
    const result = await withTimeout(
      Promise.resolve(42),
      1000
    );

    assert.strictEqual(result, 42);
  });

  it('rejects when promise times out', async () => {
    await assert.rejects(
      withTimeout(
        new Promise(() => {}), // Never resolves
        50
      ),
      /timed out/
    );
  });

  it('uses custom message', async () => {
    await assert.rejects(
      withTimeout(
        new Promise(() => {}),
        50,
        'custom timeout message'
      ),
      /custom timeout message/
    );
  });

  it('rejects immediately on error', async () => {
    await assert.rejects(
      withTimeout(
        Promise.reject(new Error('immediate error')),
        1000
      ),
      /immediate error/
    );
  });
});

describe('withDeadline', { concurrency: 4 }, () => {
  it('resolves before deadline', async () => {
    const result = await withDeadline(
      Promise.resolve('success'),
      1000
    );

    assert.strictEqual(result, 'success');
  });

  it('rejects when deadline exceeded', async () => {
    await assert.rejects(
      withDeadline(
        new Promise(() => {}),
        50
      ),
      /Deadline exceeded/
    );
  });
});

// ============================================================================
// RETRY TESTS
// ============================================================================

describe('withRetry', { concurrency: 4 }, () => {
  it('succeeds on first attempt', async () => {
    let calls = 0;
    const result = await withRetry(async () => {
      calls++;
      return 42;
    }, { maxAttempts: 3, delayMs: 10 });

    assert.strictEqual(result, 42);
    assert.strictEqual(calls, 1);
  });

  it('retries on failure', async () => {
    let calls = 0;
    const result = await withRetry(async () => {
      calls++;
      if (calls < 3) throw new Error('retry me');
      return 'success';
    }, { maxAttempts: 5, delayMs: 10 });

    assert.strictEqual(result, 'success');
    assert.strictEqual(calls, 3);
  });

  it('fails after max attempts', async () => {
    let calls = 0;

    await assert.rejects(
      withRetry(async () => {
        calls++;
        throw new Error('always fails');
      }, { maxAttempts: 3, delayMs: 10 }),
      /always fails/
    );

    assert.strictEqual(calls, 3);
  });

  it('uses custom retryable check', async () => {
    let calls = 0;

    await assert.rejects(
      withRetry(async () => {
        calls++;
        throw new Error('fatal error');
      }, {
        maxAttempts: 5,
        delayMs: 10,
        retryable: (err) => !err.message.includes('fatal'),
      }),
      /fatal error/
    );

    // Should not retry fatal errors
    assert.strictEqual(calls, 1);
  });

  it('uses exponential backoff', async () => {
    const delays: number[] = [];
    let lastTime = Date.now();

    await withRetry(async () => {
      const now = Date.now();
      delays.push(now - lastTime);
      lastTime = now;
      throw new Error('retry');
    }, {
      maxAttempts: 4,
      delayMs: 50,
      backoffMultiplier: 2,
      maxDelayMs: 500,
    }).catch(() => {});

    // First delay might be small (first attempt), check subsequent
    // delays should generally increase (with jitter)
    assert.ok(delays.length > 0);
  });

  it('respects maxDelayMs', async () => {
    let calls = 0;
    const start = Date.now();

    await withRetry(async () => {
      calls++;
      throw new Error('retry');
    }, {
      maxAttempts: 5,
      delayMs: 1000,
      backoffMultiplier: 10,
      maxDelayMs: 50, // Cap at 50ms
    }).catch(() => {});

    const duration = Date.now() - start;
    // Should complete quickly due to maxDelayMs cap
    assert.ok(duration < 1000, `Duration ${duration}ms exceeded expected limit`);
  });
});
