/**
 * Integration Tests for Test Runner
 * 
 * Validates the complete test runner pipeline including:
 * - File discovery
 * - Concurrent execution
 * - Reporter output
 * - Exit code handling
 * - Coverage integration
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { promisify } from 'node:util';

const execAsync = promisify(spawn);

// ============================================================================
// TEST RUNNER INTEGRATION
// ============================================================================

describe('Test Runner Integration', { concurrency: 2, timeout: 30000 }, () => {
  const runnerPath = resolve(process.cwd(), 'scripts/run-tests.ts');
  const nodeFlags = ['--experimental-strip-types'];

  it('runs unit tests successfully', async () => {
    const result = await runTestCommand([
      ...nodeFlags,
      runnerPath,
      'tests/unit/core.test.ts',
    ]);

    assert.strictEqual(result.exitCode, 0, `Runner failed: ${result.stderr}`);
    assert.ok(result.stdout.includes('passed'), 'Should show passed tests');
  });

  it('runs with strict mode enabled', async () => {
    const result = await runTestCommand(
      ['STRICT_MODE=true', ...nodeFlags, runnerPath, 'tests/unit/core.test.ts'],
      { env: { ...process.env, STRICT_MODE: 'true' } }
    );

    assert.strictEqual(result.exitCode, 0, `Strict mode failed: ${result.stderr}`);
  });

  it('fails on test errors', async () => {
    // Create a temporary failing test
    const failingTest = `
      import { describe, it } from 'node:test';
      import assert from 'node:assert/strict';
      describe('failing', () => {
        it('should fail', () => { assert.strictEqual(1, 2); });
      });
    `;

    const fs = await import('node:fs');
    const tmpFile = '/tmp/failing-test.tmp.test.ts';
    fs.writeFileSync(tmpFile, failingTest);

    try {
      const result = await runTestCommand([
        ...nodeFlags,
        runnerPath,
        tmpFile,
      ]);

      assert.strictEqual(result.exitCode, 1, 'Should exit with code 1 on failure');
      assert.ok(result.stdout.includes('failed') || result.stderr.includes('failed'), 
        'Should indicate test failure');
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });

  it('handles missing test files gracefully', async () => {
    const result = await runTestCommand([
      ...nodeFlags,
      runnerPath,
      'tests/nonexistent/**/*.test.ts',
    ]);

    assert.strictEqual(result.exitCode, 4, 'Should exit with NO_FILES code');
    assert.ok(result.stderr.includes('No test files found'), 
      'Should indicate no files found');
  });

  it('runs with CI reporter (tap)', async () => {
    const result = await runTestCommand(
      [...nodeFlags, runnerPath, 'tests/unit/core.test.ts'],
      { env: { ...process.env, CI: 'true' } }
    );

    assert.strictEqual(result.exitCode, 0);
    // TAP format starts with "TAP version 14"
    assert.ok(result.stdout.includes('TAP') || result.stdout.includes('ok'),
      'Should use TAP reporter format');
  });

  it('respects concurrency setting', async () => {
    const startTime = Date.now();
    const result = await runTestCommand(
      [...nodeFlags, runnerPath, 'tests/unit/**/*.test.ts'],
      { env: { ...process.env, TEST_CONCURRENCY: '1' } }
    );
    const duration = Date.now() - startTime;

    assert.strictEqual(result.exitCode, 0);
    assert.ok(duration > 0, 'Should take measurable time');
  });

  it('handles timeout correctly', async () => {
    const slowTest = `
      import { describe, it } from 'node:test';
      describe('slow', () => {
        it('should timeout', async () => {
          await new Promise(r => setTimeout(r, 10000));
        });
      });
    `;

    const fs = await import('node:fs');
    const tmpFile = '/tmp/slow-test.tmp.test.ts';
    fs.writeFileSync(tmpFile, slowTest);

    try {
      const result = await runTestCommand(
        [...nodeFlags, runnerPath, tmpFile],
        { env: { ...process.env, TEST_TIMEOUT_MS: '100' } }
      );

      assert.strictEqual(result.exitCode, 1, 'Should fail on timeout');
    } finally {
      fs.unlinkSync(tmpFile);
    }
  });
});

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

interface CommandResult {
  exitCode: number;
  stdout: string;
  stderr: string;
}

async function runTestCommand(
  args: string[],
  options: { env?: NodeJS.ProcessEnv; cwd?: string } = {}
): Promise<CommandResult> {
  return new Promise((resolve, reject) => {
    const child = spawn('node', args, {
      cwd: options.cwd || process.cwd(),
      env: options.env || process.env,
      shell: false,
    });

    let stdout = '';
    let stderr = '';

    child.stdout?.on('data', (data: Buffer) => {
      stdout += data.toString();
    });

    child.stderr?.on('data', (data: Buffer) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      resolve({
        exitCode: code ?? 1,
        stdout,
        stderr,
      });
    });

    child.on('error', reject);
  });
}
