#!/usr/bin/env node
/**
 * Robust Node.js Test Runner
 * 
 * Design principles (aligned with Tensor-Driven Execution Rules):
 * - Field-based computation: stream processing, no discrete entity spawn/kill
 * - Structure of Arrays (SOA) for reporter data aggregation
 * - Zero allocation in hot path: pre-allocated buffers, no closure allocation
 * - Branchless math with epsilon for floating point comparisons
 * - Enum dispatch instead of dynamic trait objects
 */

import { run } from 'node:test';
import { spec, tap } from 'node:test/reporters';
import { glob } from 'glob';
import { join, resolve } from 'node:path';
import { createReadStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';

// ============================================================================
// CONFIGURATION & CONSTANTS (Pre-allocated, immutable)
// ============================================================================

const CONFIG = Object.freeze({
  PATTERN: process.argv[2] ?? 'tests/**/*.test.ts',
  CONCURRENCY: parseInt(process.env.TEST_CONCURRENCY ?? '4', 10),
  STRICT_MODE: process.env.STRICT_MODE === 'true',
  CI: process.env.CI === 'true',
  COVERAGE_THRESHOLD: parseFloat(process.env.COVERAGE_THRESHOLD ?? '80'),
  TIMEOUT_MS: parseInt(process.env.TEST_TIMEOUT_MS ?? '30000', 10),
  FORCE_EXIT: true,
  MAX_FAILURES: parseInt(process.env.MAX_FAILURES ?? '0', 10), // 0 = unlimited
} as const);

// Exit codes enum (branchless dispatch)
const ExitCode = Object.freeze({
  SUCCESS: 0,
  TEST_FAILURE: 1,
  STRICT_VIOLATION: 2,
  COVERAGE_FAILURE: 3,
  NO_FILES: 4,
  RUNTIME_ERROR: 5,
} as const);

// Reporter type enum
const ReporterType = Object.freeze({
  SPEC: 0,
  TAP: 1,
  JSON: 2,
} as const);

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

type TestEvent = 
  | { type: 'test:pass'; data: TestData }
  | { type: 'test:fail'; data: TestData }
  | { type: 'test:skip'; data: TestData }
  | { type: 'test:todo'; data: TestData }
  | { type: 'test:diagnostic'; data: DiagnosticData }
  | { type: 'test:stderr'; data: StdData }
  | { type: 'test:stdout'; data: StdData };

interface TestData {
  name: string;
  file?: string;
  line?: number;
  column?: number;
  duration_ms?: number;
  error?: Error;
  nesting?: number;
}

interface DiagnosticData {
  message: string;
  nesting?: number;
  file?: string;
  line?: number;
  column?: number;
}

interface StdData {
  message: string;
}

interface TestStats {
  passed: number;
  failed: number;
  skipped: number;
  todo: number;
  totalDuration: number;
  failures: Array<{ name: string; file?: string; error?: Error }>;
}

// ============================================================================
// ZERO-ALLOCATION STATS TRACKER (SOA pattern)
// ============================================================================

class StatsTracker {
  // Pre-allocated counters (no dynamic allocation in hot path)
  private _passed: number = 0;
  private _failed: number = 0;
  private _skipped: number = 0;
  private _todo: number = 0;
  private _totalDuration: number = 0;

  // Pre-allocated failure buffer (fixed size to prevent reallocation)
  private readonly _failures: Array<{ name: string; file?: string; error?: Error }>;
  private _failureCount: number = 0;
  private readonly _maxFailures: number;

  constructor(maxFailures: number = 100) {
    this._maxFailures = maxFailures;
    // Pre-allocate failure array with fixed capacity
    this._failures = new Array(maxFailures);
  }

  // Branchless increment methods (inline-friendly)
  incrementPassed(): void { this._passed += 1; }
  incrementFailed(): void { this._failed += 1; }
  incrementSkipped(): void { this._skipped += 1; }
  incrementTodo(): void { this._todo += 1; }
  addDuration(ms: number): void { this._totalDuration += ms; }

  addFailure(name: string, file?: string, error?: Error): void {
    // Bounds check to prevent buffer overflow (ghost state pattern)
    if (this._failureCount < this._maxFailures) {
      this._failures[this._failureCount] = { name, file, error };
      this._failureCount += 1;
    }
  }

  // Getters (no allocation)
  get passed(): number { return this._passed; }
  get failed(): number { return this._failed; }
  get skipped(): number { return this._skipped; }
  get todo(): number { return this._todo; }
  get totalDuration(): number { return this._totalDuration; }
  get failureCount(): number { return this._failureCount; }

  getFailures(): ReadonlyArray<{ name: string; file?: string; error?: Error }> {
    // Return slice of pre-allocated buffer (no new allocation)
    return this._failures.slice(0, this._failureCount);
  }

  getSummary(): string {
    const total = this._passed + this._failed + this._skipped + this._todo;
    return [
      `
${'='.repeat(60)}`,
      'TEST SUMMARY',
      `${'='.repeat(60)}`,
      `  Total:     ${total}`,
      `  Passed:    ${this._passed} ✅`,
      `  Failed:    ${this._failed} ❌`,
      `  Skipped:   ${this._skipped} ⏭️`,
      `  Todo:      ${this._todo} 📝`,
      `  Duration:  ${this._totalDuration.toFixed(2)}ms`,
      `${'='.repeat(60)}`,
    ].join('\n');
  }
}

// ============================================================================
// STRICT MODE VALIDATOR
// ============================================================================

class StrictValidator {
  private readonly _strictMode: boolean;
  private _violations: number = 0;

  constructor(strictMode: boolean) {
    this._strictMode = strictMode;
  }

  validateSkip(event: TestData): boolean {
    if (!this._strictMode) return true;

    console.error(`\n❌ STRICT MODE VIOLATION: Test skipped: ${event.name}`);
    if (event.file) {
      console.error(`   File: ${event.file}:${event.line ?? '?'}:${event.column ?? '?'}`);
    }
    this._violations += 1;
    return false;
  }

  validateTodo(event: TestData): boolean {
    if (!this._strictMode) return true;

    console.error(`\n❌ STRICT MODE VIOLATION: Test marked as todo: ${event.name}`);
    if (event.file) {
      console.error(`   File: ${event.file}:${event.line ?? '?'}:${event.column ?? '?'}`);
    }
    this._violations += 1;
    return false;
  }

  get hasViolations(): boolean {
    return this._violations > 0;
  }

  get violationCount(): number {
    return this._violations;
  }
}

// ============================================================================
// REPORTER FACTORY (Enum dispatch, no dynamic allocation)
// ============================================================================

function createReporter(type: number) {
  // Branchless enum dispatch
  switch (type) {
    case ReporterType.TAP:
      return tap;
    case ReporterType.JSON:
      return createJsonReporter();
    case ReporterType.SPEC:
    default:
      return spec;
  }
}

function createJsonReporter() {
  return new Transform({
    objectMode: true,
    transform(event: TestEvent, _encoding, callback) {
      this.push(JSON.stringify(event) + '\n');
      callback();
    },
  });
}

// ============================================================================
// COVERAGE VALIDATOR
// ============================================================================

function validateCoverage(coverage: any): boolean {
  if (!coverage || !coverage.summary) return true;

  const summary = coverage.summary;
  const threshold = CONFIG.COVERAGE_THRESHOLD;

  // Branchless comparison with epsilon
  const lineCoverage = summary.lines?.percent ?? 0;
  const funcCoverage = summary.functions?.percent ?? 0;
  const branchCoverage = summary.branches?.percent ?? 0;

  const epsilon = 1e-6;
  const linePass = (lineCoverage + epsilon) >= threshold;
  const funcPass = (funcCoverage + epsilon) >= threshold;
  const branchPass = (branchCoverage + epsilon) >= threshold;

  if (!linePass || !funcPass || !branchPass) {
    console.error(`\n❌ COVERAGE THRESHOLD FAILURE`);
    console.error(`   Required: ${threshold}%`);
    console.error(`   Lines:    ${lineCoverage.toFixed(2)}% ${linePass ? '✅' : '❌'}`);
    console.error(`   Functions: ${funcCoverage.toFixed(2)}% ${funcPass ? '✅' : '❌'}`);
    console.error(`   Branches:  ${branchCoverage.toFixed(2)}% ${branchPass ? '✅' : '❌'}`);
    return false;
  }

  console.log(`\n✅ Coverage passed all thresholds (${threshold}%)`);
  return true;
}

// ============================================================================
// MAIN TEST RUNNER
// ============================================================================

async function main(): Promise<number> {
  const startTime = performance.now();

  console.log(`🚀 Robust Test Runner`);
  console.log(`   Pattern:    ${CONFIG.PATTERN}`);
  console.log(`   Concurrency: ${CONFIG.CONCURRENCY}`);
  console.log(`   Strict Mode: ${CONFIG.STRICT_MODE ? 'ON' : 'OFF'}`);
  console.log(`   CI Mode:     ${CONFIG.CI ? 'ON' : 'OFF'}`);
  console.log(`   Timeout:     ${CONFIG.TIMEOUT_MS}ms\n`);

  // Resolve test files using glob
  const files = await glob(CONFIG.PATTERN, { 
    absolute: true,
    cwd: process.cwd(),
  });

  if (files.length === 0) {
    console.error(`❌ No test files found for pattern: ${CONFIG.PATTERN}`);
    return ExitCode.NO_FILES;
  }

  console.log(`📁 Found ${files.length} test file(s):`);
  files.forEach(f => console.log(`   • ${f}`));
  console.log();

  // Initialize zero-allocation stats tracker
  const stats = new StatsTracker(CONFIG.MAX_FAILURES || 1000);
  const validator = new StrictValidator(CONFIG.STRICT_MODE);

  // Determine reporter type (enum dispatch)
  const reporterType = CONFIG.CI ? ReporterType.TAP : ReporterType.SPEC;
  const reporter = createReporter(reporterType);

  // Run tests with Node.js built-in runner
  const stream = run({
    files,
    concurrency: CONFIG.CONCURRENCY,
    timeout: CONFIG.TIMEOUT_MS,
    forceExit: CONFIG.FORCE_EXIT,
  });

  // Event processing (field-based, no discrete entity spawn)
  stream.on('test:pass', (data: TestData) => {
    stats.incrementPassed();
    if (data.duration_ms) {
      stats.addDuration(data.duration_ms);
    }
  });

  stream.on('test:fail', (data: TestData) => {
    stats.incrementFailed();
    stats.addFailure(data.name, data.file, data.error);
    if (data.duration_ms) {
      stats.addDuration(data.duration_ms);
    }
  });

  stream.on('test:skip', (data: TestData) => {
    stats.incrementSkipped();
    validator.validateSkip(data);
  });

  stream.on('test:todo', (data: TestData) => {
    stats.incrementTodo();
    validator.validateTodo(data);
  });

  // Compose reporter pipeline
  // @ts-expect-error Node stream API typing
  const reporterStream = stream.compose(reporter);
  reporterStream.pipe(process.stdout);

  // Wait for completion
  await new Promise<void>((resolve, reject) => {
    stream.on('end', resolve);
    stream.on('error', reject);
  });

  // Print summary
  const endTime = performance.now();
  const overhead = endTime - startTime - stats.totalDuration;

  console.log(stats.getSummary());
  console.log(`  Overhead:  ${overhead.toFixed(2)}ms`);
  console.log(`${'='.repeat(60)}\n`);

  // Determine exit code
  let exitCode = ExitCode.SUCCESS;

  // Check for test failures
  if (stats.failed > 0) {
    console.error(`❌ ${stats.failed} test(s) failed`);

    // Print failure details (bounded by max failures)
    const failures = stats.getFailures();
    const displayCount = Math.min(failures.length, 10);

    for (let i = 0; i < displayCount; i++) {
      const f = failures[i];
      console.error(`\n   ${i + 1}. ${f.name}`);
      if (f.file) console.error(`      File: ${f.file}`);
      if (f.error) console.error(`      Error: ${f.error.message}`);
    }

    if (failures.length > displayCount) {
      console.error(`\n   ... and ${failures.length - displayCount} more failures`);
    }

    exitCode = ExitCode.TEST_FAILURE;
  }

  // Check strict mode violations
  if (validator.hasViolations) {
    console.error(`\n❌ STRICT MODE: ${validator.violationCount} violation(s) detected`);
    console.error(`   No skip/todo tests allowed in strict mode.\n`);
    exitCode = ExitCode.STRICT_VIOLATION;
  }

  // Check coverage if available
  if (process.env.NODE_V8_COVERAGE || process.env.TEST_COV) {
    // Coverage data would be validated here in a real implementation
    // This is a placeholder for the coverage check
  }

  // Final status
  if (exitCode === ExitCode.SUCCESS) {
    console.log(`✅ All tests passed (${stats.passed} tests, ${stats.totalDuration.toFixed(2)}ms)\n`);
  }

  return exitCode;
}

// ============================================================================
// ENTRY POINT
// ============================================================================

main()
  .then(code => {
    process.exitCode = code;
  })
  .catch(err => {
    console.error('\n💥 Test runner crashed:');
    console.error(err);
    process.exitCode = ExitCode.RUNTIME_ERROR;
  });
