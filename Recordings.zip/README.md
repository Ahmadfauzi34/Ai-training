# Robust Node.js Test Runner

A production-ready, strict TypeScript test runner built on Node.js native `node:test` with zero-allocation hot path optimizations, epsilon-based floating point assertions, and comprehensive strict mode validation.

## 🎯 Design Principles

Aligned with **Tensor-Driven Execution Rules**:
- **Field-based computation**: Stream processing pipeline, no discrete entity spawn/kill
- **Structure of Arrays (SOA)**: Pre-allocated buffers for stats tracking
- **Zero allocation hot path**: No closure allocation, no `Vec::remove` patterns
- **Branchless math**: Epsilon-based comparisons with `Math.abs`
- **Enum dispatch**: Reporter selection via constants, no dynamic trait objects

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Run all tests
npm test

# Run unit tests only
npm run test:unit

# Run integration tests
npm run test:integration

# Strict mode (no skip/todo allowed)
npm run test:strict

# With coverage
npm run test:coverage

# CI mode (TAP reporter + strict)
npm run test:ci
```

## 📁 Project Structure

```
robust-test-runner/
├── scripts/
│   └── run-tests.ts          # Main test runner entry point
├── src/
│   └── core/
│       ├── test-runner.ts    # Core utilities & assertions
│       └── index.ts          # Barrel exports
├── tests/
│   ├── unit/
│   │   ├── core.test.ts      # Core utility tests
│   │   └── math-utils.test.ts # Math operation tests
│   └── integration/
│       └── runner-integration.test.ts # Runner pipeline tests
├── package.json
└── tsconfig.json
```

## 🔧 Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `TEST_CONCURRENCY` | `4` | Number of concurrent test files |
| `STRICT_MODE` | `false` | Fail on skip/todo tests |
| `CI` | `false` | Use TAP reporter instead of spec |
| `TEST_TIMEOUT_MS` | `30000` | Per-test timeout in milliseconds |
| `COVERAGE_THRESHOLD` | `80` | Minimum coverage percentage |
| `MAX_FAILURES` | `0` | Max failures to display (0 = unlimited) |

### Command Line Arguments

```bash
# Pattern argument (glob pattern for test files)
node --experimental-strip-types scripts/run-tests.ts 'tests/unit/**/*.test.ts'

# Default pattern if not provided: tests/**/*.test.ts
```

## 🧪 Core Features

### 1. Epsilon-Based Floating Point Assertions

```typescript
import { StrictAssertions, nearEqual } from './src/core/index.js';

// Absolute epsilon comparison
StrictAssertions.nearEqual(0.1 + 0.2, 0.3); // ✅ passes

// Relative comparison for large numbers
StrictAssertions.nearEqualRelative(1e9 + 100, 1e9);

// ULP-based comparison (most robust)
StrictAssertions.nearEqualUlp(Math.nextafter(1.0, 2.0), 1.0, 1);

// Array comparison with unrolled loops
StrictAssertions.arrayNearEqual(
  [1.0, 2.0, 3.0],
  [1.0 + 1e-10, 2.0, 3.0]
);
```

### 2. Zero-Allocation Stats Tracker

```typescript
import { StatsTracker } from './src/core/index.js';

// Pre-allocated buffers, no dynamic allocation during test execution
const stats = new StatsTracker(1000); // max 1000 failures tracked

stats.incrementPassed();
stats.incrementFailed();
stats.addFailure('test name', 'file.ts', error);

console.log(stats.getSummary());
```

### 3. Memory Leak Detection

```typescript
import { MemoryLeakDetector } from './src/core/index.js';

const detector = new MemoryLeakDetector(1024 * 1024); // 1MB threshold
detector.start();

// ... your test code ...

detector.check('after operation'); // throws if heap grew > 1MB
```

### 4. Performance Benchmarks

```typescript
import { benchmark } from './src/core/index.js';

const result = benchmark('my operation', () => {
  // code to benchmark
}, 100000);

console.log(`${result.opsPerSecond.toFixed(0)} ops/sec`);
```

### 5. Test Suite Builder (Fluent API)

```typescript
import { TestSuite } from './src/core/index.js';

new TestSuite({ name: 'My Suite', concurrency: 4 })
  .before(() => { /* setup */ })
  .beforeEach(() => { /* per-test setup */ })
  .test('test 1', () => { /* assertions */ })
  .test('test 2', () => { /* assertions */ })
  .afterEach(() => { /* cleanup */ })
  .after(() => { /* teardown */ })
  .build();
```

## 🔒 Strict Mode

When `STRICT_MODE=true`:
- ❌ Any `skip` test causes failure
- ❌ Any `todo` test causes failure
- ✅ All tests must be fully implemented
- ✅ Exit code 2 on strict violations

```bash
STRICT_MODE=true npm test
```

## 📊 Coverage

```bash
# Run with coverage (Node.js built-in)
npm run test:coverage

# CI mode with coverage threshold
COVERAGE_THRESHOLD=90 npm run test:ci
```

## 🎨 Reporters

- **Spec** (default): Human-readable tree format
- **TAP**: Test Anything Protocol (CI mode)
- **JSON**: Machine-parseable output

## ⚡ Performance Optimizations

1. **Pre-allocated Float64Array** for benchmark timings
2. **Unrolled loops** in array comparison (4 elements at a time)
3. **Enum dispatch** for reporter selection (no dynamic lookup)
4. **Ghost state pattern** for failure buffer bounds checking
5. **No closure allocation** in hot event handlers

## 🧪 Example Test Patterns

### Vector Math Tests
```typescript
describe('Vector2D', { concurrency: 4 }, () => {
  it('normalizes to unit length', () => {
    const v = normalize({ x: 3, y: 4 });
    StrictAssertions.nearEqual(vectorLength(v), 1.0, 1e-15);
  });

  it('handles zero vector', () => {
    const v = normalize({ x: 0, y: 0 });
    StrictAssertions.nearEqual(v.x, 0);
    StrictAssertions.nearEqual(v.y, 0);
  });
});
```

### Async Tests with Timeout
```typescript
it('resolves within timeout', async () => {
  const result = await StrictAssertions.resolvesWithin(
    fetchData(),
    5000 // 5 second timeout
  );
  StrictAssertions.defined(result);
});
```

### Error Handling Tests
```typescript
it('throws on invalid input', () => {
  StrictAssertions.throws(
    () => divide(10, 0),
    /Division by zero/
  );
});
```

## 📋 Requirements

- **Node.js**: >= 20.0.0
- **TypeScript**: >= 5.4.0
- **Flags**: `--experimental-strip-types` (or `--experimental-transform-types` for complex types)

## 🔧 TypeScript Configuration

The included `tsconfig.json` uses strict settings:
- `strict: true`
- `exactOptionalPropertyTypes: true`
- `noUncheckedIndexedAccess: true`
- `verbatimModuleSyntax: true`

## 📝 License

MIT
